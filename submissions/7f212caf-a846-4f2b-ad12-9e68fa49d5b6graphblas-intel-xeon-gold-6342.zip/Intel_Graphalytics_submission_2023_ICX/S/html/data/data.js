var data = {
  "id": "b563918",
  "specification": "1.0.0",
  "description": "",
  "system": {
    "platform": {
      "name": "GraphBLAS",
      "acronym": "graphblas",
      "version": "1.0",
      "link": "https://github.com/FTSRG/ldbc-graphalytics-platform-graphblas"
    },
    "environment": {
      "name": "",
      "acronym": "",
      "version": "",
      "link": "",
      "machines": [
        {
          "quantity": "",
          "cpu": "",
          "memory": "",
          "network": "",
          "storage": ""
        }
      ]
    },
    "tool": {
      "graphalytics-core": {
        "name": "graphalytics-core",
        "version": "1.10.0",
        "link": "https://github.com/ldbc/ldbc_graphalytics"
      },
      "graphalytics-platforms-graphblas": {
        "name": "graphalytics-platforms-graphblas",
        "version": "0.1.0-SNAPSHOT",
        "link": "https://github.com/atlarge-research/graphalytics-platforms-graphblas"
      }
    },
    "pricing": ""
  },
  "benchmark": {
    "type": "custom",
    "name": "Custom Benchmark",
    "duration": "1926150",
    "timeout": "3600",
    "resources": {},
    "output": {
      "required": "-",
      "directory": "./output/"
    },
    "validation": {
      "required": "-",
      "directory": "/home/devcloud/graphalytics_data/S/"
    },
    "configurations": {
      "graph.datagen-8_9-fb.edge-properties.types": "real",
      "environment.machine.memory": "",
      "graph.datagen-8_3-zf.cdlp.max-iterations": "10",
      "graph.datagen-9_4-fb.sssp.weight-property": "weight",
      "graph.graph500-27.meta.vertices": "63081040",
      "graph.test-bfs-undirected.vertex-file": "test-bfs-undirected.v",
      "graph.cit-Patents.algorithms": "bfs",
      "graph.datagen-8_9-fb.sssp.source-vertex": "6",
      "graph.graph500-24.edge-file": "graph500-24.e",
      "graph.datagen-8_4-fb.vertex-file": "datagen-8_4-fb.v",
      "graph.datagen-9_1-fb.meta.vertices": "16087483",
      "graph.example-undirected.meta.vertices": "9",
      "graph.com-friendster.cdlp.max-iterations": "10",
      "graph.test-pr-directed.edge-file": "test-pr-directed.e",
      "graph.cit-Patents.vertex-file": "cit-Patents.v",
      "graph.datagen-7_9-fb.vertex-file": "datagen-7_9-fb.v",
      "graph.test-bfs-undirected.bfs.source-vertex": "1",
      "graph.kgs.cdlp.max-iterations": "10",
      "graph.kgs.meta.vertices": "832247",
      "environment.machine.storage": "",
      "graph.datagen-8_7-zf.bfs.source-vertex": "6",
      "benchmark.runner.max-memory": "",
      "graph.datagen-sf3k-fb.pr.num-iterations": "10",
      "graph.datagen-8_3-zf.meta.vertices": "53525014",
      "graph.datagen-8_1-fb.algorithms": "bfs",
      "graph.datagen-7_7-zf.meta.edges": "32791267",
      "graph.datagen-8_7-zf.vertex-file": "datagen-8_7-zf.v",
      "graph.datagen-8_8-zf.meta.vertices": "168308893",
      "graph.datagen-9_2-zf.vertex-file": "datagen-9_2-zf.v",
      "graph.dota-league.cdlp.max-iterations": "10",
      "graph.datagen-sf3k-fb.pr.damping-factor": "0.85",
      "graph.datagen-8_5-fb.sssp.source-vertex": "6",
      "graph.datagen-8_8-zf.edge-properties.types": "real",
      "graph.graph500-22.cdlp.max-iterations": "10",
      "graph.graph500-23.algorithms": "bfs",
      "graph.graph500-22.edge-file": "graph500-22.e",
      "graph.datagen-8_0-fb.edge-properties.names": "weight",
      "graph.datagen-8_0-fb.meta.vertices": "1706561",
      "graph.example-undirected.edge-properties.names": "weight",
      "graph.datagen-8_0-fb.algorithms": "bfs",
      "graph.datagen-9_4-fb.edge-properties.types": "real",
      "graph.datagen-7_7-zf.algorithms": "bfs",
      "graph.datagen-8_0-fb.bfs.source-vertex": "6",
      "graph.twitter_mpi.cdlp.max-iterations": "10",
      "graph.graph500-22.bfs.source-vertex": "248533",
      "graph.graph500-30.pr.damping-factor": "0.85",
      "graph.example-directed.bfs.source-vertex": "1",
      "graph.datagen-9_1-fb.edge-properties.types": "real",
      "graph.datagen-sf10k-fb.algorithms": "bfs",
      "graph.datagen-8_5-fb.vertex-file": "datagen-8_5-fb.v",
      "graph.datagen-sf10k-fb.vertex-file": "datagen-sf10k-fb.v",
      "graph.datagen-8_9-fb.cdlp.max-iterations": "10",
      "graph.com-friendster.meta.edges": "1806067135",
      "graph.graph500-26.meta.vertices": "32804978",
      "graph.datagen-7_8-zf.algorithms": "bfs",
      "graph.datagen-9_2-zf.sssp.weight-property": "weight",
      "graph.datagen-9_2-zf.sssp.source-vertex": "6",
      "graph.datagen-7_5-fb.algorithms": "bfs",
      "graph.graph500-24.bfs.source-vertex": "2592222",
      "graph.datagen-7_6-fb.edge-file": "datagen-7_6-fb.e",
      "graph.datagen-8_8-zf.bfs.source-vertex": "6",
      "graph.test-wcc-directed.meta.edges": "10",
      "graph.dota-league.meta.vertices": "61170",
      "graph.datagen-sf10k-fb.cdlp.max-iterations": "10",
      "graph.datagen-7_7-zf.meta.vertices": "13180508",
      "graph.datagen-7_5-fb.meta.edges": "34185747",
      "graph.example-directed.edge-properties.types": "real",
      "graph.datagen-7_8-zf.edge-file": "datagen-7_8-zf.e",
      "graph.test-pr-directed.pr.damping-factor": "0.85",
      "graph.test-pr-undirected.pr.num-iterations": "26",
      "graph.datagen-9_2-zf.pr.damping-factor": "0.85",
      "graph.datagen-9_3-zf.pr.num-iterations": "10",
      "graph.datagen-9_3-zf.edge-properties.types": "real",
      "graph.graph500-28.meta.vertices": "121242388",
      "graph.test-sssp-undirected.algorithms": "sssp",
      "graph.datagen-7_5-fb.edge-properties.names": "weight",
      "graph.test-wcc-directed.vertex-file": "test-wcc-directed.v",
      "graph.datagen-8_2-zf.bfs.source-vertex": "6",
      "graph.test-bfs-undirected.directed": "false",
      "graph.test-sssp-undirected.sssp.source-vertex": "1",
      "graph.twitter_mpi.meta.edges": "1963263508",
      "graph.datagen-7_7-zf.edge-properties.names": "weight",
      "graph.dota-league.edge-properties.types": "real",
      "graph.datagen-9_4-fb.edge-properties.names": "weight",
      "graph.datagen-9_3-zf.vertex-file": "datagen-9_3-zf.v",
      "graph.datagen-7_9-fb.edge-properties.names": "weight",
      "graph.datagen-8_9-fb.sssp.weight-property": "weight",
      "graph.datagen-8_2-zf.sssp.source-vertex": "6",
      "graph.graph500-26.cdlp.max-iterations": "10",
      "graph.test-lcc-undirected.directed": "false",
      "graph.graph500-26.bfs.source-vertex": "62455266",
      "graph.test-pr-undirected.vertex-file": "test-pr-undirected.v",
      "graph.datagen-9_4-fb.meta.vertices": "29310565",
      "graph.test-cdlp-undirected.edge-file": "test-cdlp-undirected.e",
      "graph.test-bfs-undirected.edge-file": "test-bfs-undirected.e",
      "graph.graph500-27.bfs.source-vertex": "0",
      "graph.test-sssp-directed.vertex-file": "test-sssp-directed.v",
      "graph.datagen-8_4-fb.sssp.weight-property": "weight",
      "graph.datagen-8_1-fb.meta.edges": "134267822",
      "graph.graph500-27.cdlp.max-iterations": "10",
      "graph.graph500-30.pr.num-iterations": "10",
      "graph.graph500-30.vertex-file": "graph500-30.v",
      "graph.example-undirected.sssp.source-vertex": "2",
      "graph.twitter_mpi.algorithms": "bfs",
      "graph.datagen-sf3k-fb.bfs.source-vertex": "933",
      "graph.test-sssp-undirected.edge-file": "test-sssp-undirected.e",
      "graph.datagen-7_5-fb.directed": "false",
      "graph.graph500-25.directed": "false",
      "graph.datagen-9_1-fb.pr.num-iterations": "10",
      "graph.datagen-sf10k-fb.pr.num-iterations": "10",
      "graph.datagen-7_9-fb.edge-file": "datagen-7_9-fb.e",
      "graph.datagen-8_4-fb.bfs.source-vertex": "6",
      "graph.wiki-Talk.edge-file": "wiki-Talk.e",
      "graph.dota-league.pr.damping-factor": "0.85",
      "graph.graph500-28.algorithms": "bfs",
      "graph.datagen-9_3-zf.edge-properties.names": "weight",
      "graph.cit-Patents.edge-file": "cit-Patents.e",
      "graph.twitter_mpi.edge-file": "twitter_mpi.e",
      "graph.cit-Patents.directed": "true",
      "graph.datagen-7_5-fb.edge-properties.types": "real",
      "graph.test-wcc-undirected.edge-file": "test-wcc-undirected.e",
      "graph.datagen-8_5-fb.directed": "false",
      "graph.datagen-8_9-fb.directed": "false",
      "graph.datagen-8_5-fb.cdlp.max-iterations": "10",
      "graph.cit-Patents.meta.vertices": "3774768",
      "graph.datagen-7_6-fb.meta.edges": "42162988",
      "graph.datagen-8_2-zf.pr.num-iterations": "10",
      "graph.graph500-29.meta.vertices": "232999630",
      "graph.datagen-8_0-fb.meta.edges": "107507376",
      "graph.datagen-sf3k-fb.edge-file": "datagen-sf3k-fb.e",
      "graph.datagen-9_0-fb.vertex-file": "datagen-9_0-fb.v",
      "graph.graph500-23.bfs.source-vertex": "7348998",
      "graph.test-sssp-undirected.meta.vertices": "12",
      "graph.datagen-9_1-fb.sssp.source-vertex": "6",
      "graph.datagen-8_4-fb.edge-file": "datagen-8_4-fb.e",
      "graph.wiki-Talk.meta.edges": "5021410",
      "graph.datagen-9_0-fb.pr.damping-factor": "0.85",
      "graph.datagen-8_6-fb.vertex-file": "datagen-8_6-fb.v",
      "graph.datagen-8_1-fb.directed": "false",
      "graph.example-undirected.directed": "false",
      "graph.datagen-7_9-fb.directed": "false",
      "platform.acronym": "graphblas",
      "graph.test-bfs-directed.directed": "true",
      "graph.datagen-7_5-fb.edge-file": "datagen-7_5-fb.e",
      "graph.test-sssp-directed.sssp.source-vertex": "1",
      "graph.kgs.algorithms": "bfs",
      "graph.test-cdlp-directed.algorithms": "cdlp",
      "graph.com-friendster.edge-file": "com-friendster.e",
      "graph.dota-league.sssp.weight-property": "weight",
      "graph.datagen-7_9-fb.meta.vertices": "1387587",
      "graph.datagen-8_1-fb.edge-properties.names": "weight",
      "graph.wiki-Talk.algorithms": "bfs",
      "graph.graph500-25.vertex-file": "graph500-25.v",
      "graph.test-sssp-directed.edge-properties.names": "weight",
      "graph.datagen-8_2-zf.algorithms": "bfs",
      "graph.com-friendster.pr.damping-factor": "0.85",
      "graph.graph500-28.vertex-file": "graph500-28.v",
      "graph.datagen-9_1-fb.directed": "false",
      "graph.datagen-9_3-zf.meta.edges": "1309998551",
      "graph.example-undirected.bfs.source-vertex": "2",
      "graph.kgs.sssp.weight-property": "weight",
      "graph.graph500-29.vertex-file": "graph500-29.v",
      "graph.test-wcc-directed.meta.vertices": "8",
      "graph.datagen-7_6-fb.pr.damping-factor": "0.85",
      "graph.test-bfs-undirected.algorithms": "bfs",
      "environment.machine.cpu": "",
      "graph.test-sssp-undirected.vertex-file": "test-sssp-undirected.v",
      "graph.datagen-7_7-zf.sssp.weight-property": "weight",
      "environment.acronym": "",
      "graph.dota-league.meta.edges": "50870313",
      "graph.datagen-sf3k-fb.edge-properties.types": "real",
      "graph.datagen-8_1-fb.vertex-file": "datagen-8_1-fb.v",
      "graph.datagen-8_7-zf.pr.num-iterations": "10",
      "graph.datagen-9_0-fb.meta.edges": "1049527225",
      "graph.datagen-7_8-zf.meta.vertices": "16521886",
      "graph.test-wcc-undirected.meta.edges": "7",
      "graph.example-undirected.edge-file": "example-undirected.e",
      "graph.datagen-8_8-zf.edge-file": "datagen-8_8-zf.e",
      "graph.datagen-sf3k-fb.sssp.weight-property": "weight",
      "graph.graph500-24.vertex-file": "graph500-24.v",
      "graph.test-cdlp-undirected.meta.edges": "13",
      "graph.datagen-sf3k-fb.vertex-file": "datagen-sf3k-fb.v",
      "graph.graph500-27.meta.edges": "2111642032",
      "graph.datagen-7_6-fb.algorithms": "bfs",
      "graph.graph500-25.meta.vertices": "17062472",
      "graph.datagen-7_8-zf.directed": "false",
      "graph.datagen-9_3-zf.sssp.weight-property": "weight",
      "graph.datagen-8_5-fb.bfs.source-vertex": "6",
      "graph.example-directed.vertex-file": "example-directed.v",
      "graph.datagen-8_3-zf.directed": "false",
      "graph.example-directed.algorithms": "bfs",
      "graph.kgs.sssp.source-vertex": "239044",
      "graph.datagen-7_6-fb.edge-properties.names": "weight",
      "graph.datagen-8_1-fb.cdlp.max-iterations": "10",
      "graph.datagen-8_9-fb.edge-properties.names": "weight",
      "graph.test-wcc-directed.directed": "true",
      "graph.example-undirected.meta.edges": "12",
      "graph.test-lcc-undirected.edge-file": "test-lcc-undirected.e",
      "graph.datagen-8_8-zf.directed": "false",
      "graph.datagen-8_9-fb.algorithms": "bfs",
      "graph.graph500-23.pr.damping-factor": "0.85",
      "graph.datagen-8_7-zf.directed": "false",
      "graph.graph500-30.algorithms": "bfs",
      "graph.datagen-8_0-fb.vertex-file": "datagen-8_0-fb.v",
      "graph.graph500-24.meta.vertices": "8870942",
      "graph.datagen-8_6-fb.edge-properties.names": "weight",
      "graph.graph500-28.edge-file": "graph500-28.e",
      "graph.graph500-29.directed": "false",
      "benchmark.runner.port": "8012",
      "graph.datagen-7_9-fb.pr.damping-factor": "0.85",
      "graph.datagen-8_8-zf.sssp.weight-property": "weight",
      "graph.graph500-29.bfs.source-vertex": "0",
      "graph.datagen-9_0-fb.edge-properties.types": "real",
      "graph.datagen-8_3-zf.algorithms": "bfs",
      "graph.datagen-7_5-fb.sssp.source-vertex": "6",
      "graph.com-friendster.directed": "false",
      "graph.datagen-9_2-zf.meta.edges": "1042340732",
      "graph.datagen-7_7-zf.directed": "false",
      "graph.datagen-8_0-fb.sssp.weight-property": "weight",
      "benchmark.description": "",
      "graph.test-pr-directed.pr.num-iterations": "14",
      "graph.datagen-8_3-zf.vertex-file": "datagen-8_3-zf.v",
      "graph.graph500-22.algorithms": "bfs",
      "graph.graph500-23.pr.num-iterations": "10",
      "benchmark.custom.validation-required": "true",
      "graph.datagen-8_1-fb.sssp.source-vertex": "6",
      "graph.datagen-9_0-fb.meta.vertices": "12857671",
      "graph.datagen-8_2-zf.sssp.weight-property": "weight",
      "graph.datagen-7_7-zf.vertex-file": "datagen-7_7-zf.v",
      "graph.datagen-8_5-fb.meta.vertices": "4599739",
      "graph.test-sssp-directed.edge-file": "test-sssp-directed.e",
      "graph.graph500-27.edge-file": "graph500-27.e",
      "graph.graph500-24.pr.damping-factor": "0.85",
      "graph.datagen-8_0-fb.sssp.source-vertex": "6",
      "graph.datagen-9_1-fb.edge-properties.names": "weight",
      "graph.datagen-8_8-zf.algorithms": "bfs",
      "benchmark.custom.graphs": "graph500-22",
      "graph.test-sssp-directed.meta.edges": "13",
      "graph.datagen-8_9-fb.edge-file": "datagen-8_9-fb.e",
      "graph.datagen-8_7-zf.cdlp.max-iterations": "10",
      "graph.example-directed.sssp.source-vertex": "1",
      "graph.kgs.pr.damping-factor": "0.85",
      "graph.datagen-9_4-fb.pr.damping-factor": "0.85",
      "graph.datagen-9_2-zf.edge-properties.names": "weight",
      "environment.machine.network": "",
      "graph.twitter_mpi.vertex-file": "twitter_mpi.v",
      "graph.datagen-8_1-fb.bfs.source-vertex": "6",
      "graph.test-sssp-undirected.directed": "false",
      "graph.datagen-9_3-zf.pr.damping-factor": "0.85",
      "graph.datagen-8_1-fb.pr.num-iterations": "10",
      "graph.datagen-8_2-zf.pr.damping-factor": "0.85",
      "graph.graph500-26.edge-file": "graph500-26.e",
      "graph.datagen-9_1-fb.meta.edges": "1342158397",
      "graph.datagen-9_3-zf.directed": "false",
      "graph.datagen-8_3-zf.pr.num-iterations": "10",
      "graph.test-sssp-undirected.edge-properties.names": "weight",
      "graph.datagen-7_8-zf.pr.damping-factor": "0.85",
      "graph.graph500-25.algorithms": "bfs",
      "graph.test-lcc-undirected.algorithms": "lcc",
      "graph.test-cdlp-undirected.vertex-file": "test-cdlp-undirected.v",
      "graph.datagen-8_3-zf.bfs.source-vertex": "6",
      "graph.datagen-9_1-fb.sssp.weight-property": "weight",
      "graph.graph500-23.meta.vertices": "4610222",
      "graph.graph500-26.directed": "false",
      "graph.datagen-8_0-fb.edge-properties.types": "real",
      "environment.link": "",
      "graph.dota-league.pr.num-iterations": "10",
      "graph.datagen-7_8-zf.meta.edges": "41025255",
      "graph.graph500-28.bfs.source-vertex": "0",
      "graph.test-bfs-directed.edge-file": "test-bfs-directed.e",
      "graph.datagen-9_4-fb.meta.edges": "2588948669",
      "graph.datagen-8_4-fb.cdlp.max-iterations": "10",
      "graph.datagen-7_6-fb.directed": "false",
      "platform.link": "https://github.com/FTSRG/ldbc-graphalytics-platform-graphblas",
      "graph.datagen-9_1-fb.pr.damping-factor": "0.85",
      "graph.datagen-sf10k-fb.pr.damping-factor": "0.85",
      "benchmark.executor.port": "8011",
      "graph.datagen-8_0-fb.pr.damping-factor": "0.85",
      "graph.graph500-22.pr.num-iterations": "10",
      "graph.test-lcc-directed.algorithms": "lcc",
      "graph.test-sssp-directed.directed": "true",
      "graph.datagen-8_2-zf.edge-file": "datagen-8_2-zf.e",
      "graph.datagen-8_4-fb.edge-properties.types": "real",
      "graph.datagen-8_6-fb.directed": "false",
      "graph.example-directed.cdlp.max-iterations": "2",
      "graph.cit-Patents.meta.edges": "16518948",
      "graph.test-bfs-undirected.meta.vertices": "10",
      "graph.graph500-29.algorithms": "bfs",
      "graph.datagen-9_1-fb.edge-file": "datagen-9_1-fb.e",
      "benchmark.custom.output-required": "true",
      "graph.graph500-23.meta.edges": "129333677",
      "graph.datagen-sf10k-fb.edge-properties.names": "weight",
      "graph.test-cdlp-undirected.cdlp.max-iterations": "5",
      "graph.graph500-29.pr.num-iterations": "10",
      "graph.datagen-8_2-zf.edge-properties.names": "weight",
      "graph.com-friendster.algorithms": "bfs",
      "graph.graph500-23.directed": "false",
      "graph.datagen-sf10k-fb.edge-file": "datagen-sf10k-fb.e",
      "graph.datagen-8_7-zf.algorithms": "bfs",
      "graph.test-cdlp-directed.directed": "true",
      "graph.graph500-30.cdlp.max-iterations": "10",
      "graph.datagen-7_6-fb.sssp.source-vertex": "6",
      "graph.datagen-8_8-zf.sssp.source-vertex": "6",
      "graph.datagen-8_4-fb.meta.vertices": "3809084",
      "graph.datagen-7_6-fb.bfs.source-vertex": "6",
      "graph.test-cdlp-directed.cdlp.max-iterations": "5",
      "graph.test-cdlp-undirected.meta.vertices": "8",
      "graph.datagen-8_3-zf.edge-file": "datagen-8_3-zf.e",
      "graph.graph500-22.meta.vertices": "2396657",
      "graph.com-friendster.bfs.source-vertex": "101",
      "graph.datagen-7_9-fb.meta.edges": "85670523",
      "graph.test-lcc-undirected.meta.vertices": "9",
      "environment.machine.quantity": "",
      "graph.datagen-7_5-fb.sssp.weight-property": "weight",
      "graph.graph500-24.algorithms": "bfs",
      "graph.example-undirected.pr.num-iterations": "2",
      "graph.graph500-29.pr.damping-factor": "0.85",
      "graphs.validation-directory": "/home/devcloud/graphalytics_data/S/",
      "graph.example-directed.sssp.weight-property": "weight",
      "graph.datagen-8_1-fb.sssp.weight-property": "weight",
      "graph.datagen-8_6-fb.algorithms": "bfs",
      "graph.datagen-8_7-zf.edge-properties.names": "weight",
      "graph.datagen-8_9-fb.pr.num-iterations": "10",
      "graph.test-wcc-undirected.meta.vertices": "8",
      "graph.datagen-8_0-fb.cdlp.max-iterations": "10",
      "graph.datagen-8_1-fb.edge-properties.types": "real",
      "graph.graph500-23.edge-file": "graph500-23.e",
      "graph.test-wcc-undirected.directed": "false",
      "graph.graph500-28.pr.damping-factor": "0.85",
      "graph.test-pr-undirected.meta.vertices": "50",
      "graph.datagen-8_7-zf.meta.vertices": "145050709",
      "graph.datagen-8_6-fb.meta.edges": "421988619",
      "graph.datagen-8_9-fb.meta.vertices": "10572901",
      "graph.datagen-8_9-fb.pr.damping-factor": "0.85",
      "graph.dota-league.bfs.source-vertex": "287770",
      "graph.graph500-27.pr.damping-factor": "0.85",
      "graph.datagen-sf10k-fb.directed": "false",
      "graph.graph500-30.edge-file": "graph500-30.e",
      "graph.datagen-7_6-fb.meta.vertices": "754147",
      "graph.test-lcc-undirected.meta.edges": "12",
      "graph.graph500-28.pr.num-iterations": "10",
      "graph.datagen-7_9-fb.cdlp.max-iterations": "10",
      "graph.datagen-8_5-fb.meta.edges": "332026902",
      "graph.datagen-8_6-fb.sssp.weight-property": "weight",
      "benchmark.name": "Custom Benchmark",
      "graph.test-lcc-directed.meta.edges": "17",
      "graph.test-cdlp-directed.meta.vertices": "8",
      "graph.datagen-7_7-zf.sssp.source-vertex": "6",
      "graph.datagen-sf10k-fb.edge-properties.types": "real",
      "graph.datagen-8_4-fb.pr.num-iterations": "10",
      "graph.test-pr-directed.vertex-file": "test-pr-directed.v",
      "graph.datagen-8_5-fb.edge-properties.names": "weight",
      "graph.test-wcc-undirected.vertex-file": "test-wcc-undirected.v",
      "benchmark.custom.timeout": "3600",
      "graph.datagen-7_5-fb.bfs.source-vertex": "6",
      "graph.datagen-9_0-fb.edge-file": "datagen-9_0-fb.e",
      "graph.datagen-8_1-fb.edge-file": "datagen-8_1-fb.e",
      "graph.datagen-8_8-zf.meta.edges": "413354288",
      "graph.datagen-7_8-zf.sssp.weight-property": "weight",
      "graph.datagen-9_1-fb.cdlp.max-iterations": "10",
      "graph.test-sssp-directed.meta.vertices": "10",
      "graph.graph500-24.cdlp.max-iterations": "10",
      "graph.graph500-25.pr.damping-factor": "0.85",
      "graph.example-undirected.pr.damping-factor": "0.85",
      "platform.name": "GraphBLAS",
      "graph.datagen-9_2-zf.bfs.source-vertex": "6",
      "graph.graph500-25.edge-file": "graph500-25.e",
      "graph.test-pr-undirected.meta.edges": "113",
      "graph.datagen-8_3-zf.edge-properties.types": "real",
      "graph.wiki-Talk.pr.num-iterations": "10",
      "graph.test-bfs-directed.meta.vertices": "10",
      "graph.datagen-9_4-fb.sssp.source-vertex": "6",
      "graph.test-pr-directed.algorithms": "pr",
      "graph.datagen-8_2-zf.meta.vertices": "43734497",
      "graph.test-sssp-directed.sssp.weight-property": "weight",
      "graph.datagen-8_2-zf.vertex-file": "datagen-8_2-zf.v",
      "graph.graph500-26.meta.edges": "1051922853",
      "graph.graph500-30.directed": "false",
      "graph.graph500-25.cdlp.max-iterations": "10",
      "graph.graph500-30.meta.vertices": "447797986",
      "graph.datagen-9_4-fb.cdlp.max-iterations": "10",
      "graph.test-bfs-directed.meta.edges": "17",
      "graph.datagen-9_1-fb.algorithms": "bfs",
      "graph.datagen-8_9-fb.vertex-file": "datagen-8_9-fb.v",
      "graph.wiki-Talk.bfs.source-vertex": "2",
      "benchmark.custom.algorithms": "BFS",
      "graph.datagen-9_3-zf.bfs.source-vertex": "6",
      "graph.wiki-Talk.vertex-file": "wiki-Talk.v",
      "graph.graph500-27.pr.num-iterations": "10",
      "graph.datagen-9_4-fb.vertex-file": "datagen-9_4-fb.v",
      "graph.datagen-9_2-zf.directed": "false",
      "graph.datagen-9_2-zf.edge-file": "datagen-9_2-zf.e",
      "graph.datagen-9_3-zf.edge-file": "datagen-9_3-zf.e",
      "graph.datagen-sf3k-fb.algorithms": "bfs",
      "graph.example-directed.directed": "true",
      "graph.datagen-8_1-fb.pr.damping-factor": "0.85",
      "graph.datagen-9_2-zf.cdlp.max-iterations": "10",
      "graph.graph500-26.algorithms": "bfs",
      "graph.datagen-7_9-fb.edge-properties.types": "real",
      "graph.datagen-8_5-fb.algorithms": "bfs",
      "environment.name": "",
      "graph.datagen-8_3-zf.sssp.source-vertex": "6",
      "graphs.output-directory": "./output/",
      "graph.datagen-sf3k-fb.meta.edges": "2912009743",
      "graph.test-bfs-directed.algorithms": "bfs",
      "graph.datagen-sf3k-fb.edge-properties.names": "weight",
      "graph.datagen-8_4-fb.pr.damping-factor": "0.85",
      "graph.example-directed.meta.edges": "17",
      "graph.wiki-Talk.cdlp.max-iterations": "10",
      "graph.datagen-8_5-fb.pr.num-iterations": "10",
      "graph.example-undirected.sssp.weight-property": "weight",
      "graph.kgs.pr.num-iterations": "10",
      "graph.example-directed.pr.num-iterations": "2",
      "graph.datagen-7_6-fb.cdlp.max-iterations": "10",
      "graph.test-bfs-directed.bfs.source-vertex": "1",
      "graph.graph500-22.pr.damping-factor": "0.85",
      "graph.graph500-29.edge-file": "graph500-29.e",
      "graph.kgs.edge-properties.types": "real",
      "graph.datagen-8_0-fb.pr.num-iterations": "10",
      "graph.graph500-22.meta.edges": "64155735",
      "graph.test-cdlp-directed.edge-file": "test-cdlp-directed.e",
      "graph.datagen-9_2-zf.meta.vertices": "434943376",
      "graph.datagen-7_7-zf.pr.damping-factor": "0.85",
      "graph.datagen-7_8-zf.edge-properties.types": "real",
      "graph.datagen-8_4-fb.algorithms": "bfs",
      "graph.graph500-28.directed": "false",
      "graph.test-sssp-undirected.sssp.weight-property": "weight",
      "graph.datagen-sf10k-fb.sssp.source-vertex": "6",
      "graph.graph500-30.bfs.source-vertex": "0",
      "graph.datagen-8_8-zf.pr.damping-factor": "0.85",
      "graph.datagen-7_8-zf.sssp.source-vertex": "6",
      "graph.datagen-7_5-fb.vertex-file": "datagen-7_5-fb.v",
      "graph.datagen-8_1-fb.meta.vertices": "2072117",
      "graph.datagen-7_9-fb.sssp.weight-property": "weight",
      "graph.dota-league.directed": "false",
      "graph.twitter_mpi.bfs.source-vertex": "420",
      "graph.datagen-8_6-fb.sssp.source-vertex": "6",
      "graph.graph500-28.cdlp.max-iterations": "10",
      "graph.datagen-7_7-zf.cdlp.max-iterations": "10",
      "graph.cit-Patents.bfs.source-vertex": "6009541",
      "graph.datagen-8_9-fb.bfs.source-vertex": "6",
      "graph.datagen-9_0-fb.edge-properties.names": "weight",
      "graph.datagen-sf3k-fb.meta.vertices": "33484375",
      "graph.graph500-24.pr.num-iterations": "10",
      "graph.graph500-24.meta.edges": "260379520",
      "graph.wiki-Talk.directed": "true",
      "graph.graph500-26.pr.damping-factor": "0.85",
      "graph.datagen-8_3-zf.edge-properties.names": "weight",
      "graph.graph500-29.cdlp.max-iterations": "10",
      "graph.datagen-7_8-zf.pr.num-iterations": "10",
      "graph.datagen-7_9-fb.algorithms": "bfs",
      "graph.datagen-8_6-fb.pr.damping-factor": "0.85",
      "graph.datagen-8_8-zf.cdlp.max-iterations": "10",
      "graph.datagen-7_6-fb.pr.num-iterations": "10",
      "graph.datagen-7_8-zf.vertex-file": "datagen-7_8-zf.v",
      "graph.datagen-7_5-fb.pr.damping-factor": "0.85",
      "graph.datagen-8_0-fb.edge-file": "datagen-8_0-fb.e",
      "graph.test-pr-directed.meta.vertices": "50",
      "graph.datagen-8_7-zf.edge-properties.types": "real",
      "graph.test-lcc-directed.vertex-file": "test-lcc-directed.v",
      "graph.datagen-8_6-fb.cdlp.max-iterations": "10",
      "graph.dota-league.edge-file": "dota-league.e",
      "graph.graph500-26.vertex-file": "graph500-26.v",
      "graph.graph500-27.algorithms": "bfs",
      "benchmark.type": "custom",
      "graph.datagen-9_0-fb.algorithms": "bfs",
      "graph.test-cdlp-undirected.algorithms": "cdlp",
      "graph.datagen-8_7-zf.sssp.source-vertex": "6",
      "graph.graph500-27.vertex-file": "graph500-27.v",
      "graph.graph500-24.directed": "false",
      "graph.kgs.edge-properties.names": "weight",
      "platform.graphblas.num-threads": "96",
      "graph.datagen-8_6-fb.meta.vertices": "5667674",
      "graph.datagen-8_5-fb.edge-properties.types": "real",
      "graph.datagen-9_4-fb.directed": "false",
      "graph.test-cdlp-directed.vertex-file": "test-cdlp-directed.v",
      "graph.example-directed.edge-file": "example-directed.e",
      "graph.datagen-7_5-fb.pr.num-iterations": "10",
      "graph.kgs.edge-file": "kgs.e",
      "graph.datagen-7_6-fb.vertex-file": "datagen-7_6-fb.v",
      "graph.test-bfs-directed.vertex-file": "test-bfs-directed.v",
      "graph.test-cdlp-directed.meta.edges": "18",
      "graph.datagen-8_2-zf.cdlp.max-iterations": "10",
      "graph.kgs.directed": "false",
      "graph.datagen-9_0-fb.cdlp.max-iterations": "10",
      "graph.test-lcc-directed.directed": "true",
      "graph.datagen-8_7-zf.edge-file": "datagen-8_7-zf.e",
      "graph.graph500-28.meta.edges": "4236163958",
      "graph.cit-Patents.pr.damping-factor": "0.85",
      "graph.dota-league.sssp.source-vertex": "287770",
      "graph.datagen-9_2-zf.edge-properties.types": "real",
      "graph.graph500-23.vertex-file": "graph500-23.v",
      "graph.graph500-22.vertex-file": "graph500-22.v",
      "graph.datagen-7_9-fb.sssp.source-vertex": "6",
      "graph.test-sssp-undirected.edge-properties.types": "real",
      "graph.datagen-7_7-zf.bfs.source-vertex": "6",
      "graph.datagen-9_0-fb.sssp.source-vertex": "6",
      "graph.test-bfs-undirected.meta.edges": "14",
      "graph.datagen-9_1-fb.bfs.source-vertex": "6",
      "graph.datagen-8_3-zf.pr.damping-factor": "0.85",
      "graphs.names": "[graph500-22, graph500-23, graph500-24, graph500-25, graph500-26, graph500-27, graph500-28, graph500-29, graph500-30, datagen-7_5-fb, datagen-7_6-fb, datagen-7_7-zf, datagen-7_8-zf, datagen-7_9-fb, datagen-8_0-fb, datagen-8_1-fb, datagen-8_2-zf, datagen-8_3-zf, datagen-8_4-fb, datagen-8_5-fb, datagen-8_6-fb, datagen-8_7-zf, datagen-8_8-zf, datagen-8_9-fb, datagen-9_0-fb, datagen-9_1-fb, datagen-9_2-zf, datagen-9_3-zf, datagen-9_4-fb, datagen-sf3k-fb, datagen-sf10k-fb, dota-league, com-friendster, twitter_mpi, cit-Patents, kgs, wiki-Talk, test-bfs-directed, test-bfs-undirected, test-cdlp-directed, test-cdlp-undirected, test-lcc-directed, test-lcc-undirected, test-pr-directed, test-pr-undirected, test-sssp-directed, test-sssp-undirected, test-wcc-directed, test-wcc-undirected, example-directed, example-undirected]",
      "graph.test-lcc-directed.edge-file": "test-lcc-directed.e",
      "graph.twitter_mpi.pr.damping-factor": "0.85",
      "graph.datagen-8_2-zf.directed": "false",
      "graph.datagen-9_0-fb.sssp.weight-property": "weight",
      "graph.datagen-7_9-fb.pr.num-iterations": "10",
      "graph.cit-Patents.pr.num-iterations": "10",
      "graph.datagen-9_3-zf.cdlp.max-iterations": "10",
      "graph.datagen-7_6-fb.sssp.weight-property": "weight",
      "graph.datagen-8_3-zf.sssp.weight-property": "weight",
      "graph.test-cdlp-undirected.directed": "false",
      "graph.dota-league.edge-properties.names": "weight",
      "graph.datagen-8_7-zf.meta.edges": "340157363",
      "graph.datagen-7_8-zf.bfs.source-vertex": "6",
      "graph.com-friendster.meta.vertices": "65608366",
      "graph.graph500-22.directed": "false",
      "graph.test-wcc-undirected.algorithms": "wcc",
      "graph.graph500-23.cdlp.max-iterations": "10",
      "graph.datagen-8_6-fb.bfs.source-vertex": "6",
      "graph.datagen-9_4-fb.edge-file": "datagen-9_4-fb.e",
      "graph.com-friendster.pr.num-iterations": "10",
      "graph.twitter_mpi.pr.num-iterations": "10",
      "graph.datagen-7_8-zf.edge-properties.names": "weight",
      "graph.datagen-8_2-zf.edge-properties.types": "real",
      "graph.datagen-9_0-fb.bfs.source-vertex": "6",
      "graph.datagen-sf3k-fb.directed": "false",
      "graph.datagen-8_4-fb.edge-properties.names": "weight",
      "graph.datagen-8_5-fb.edge-file": "datagen-8_5-fb.e",
      "graph.datagen-8_5-fb.sssp.weight-property": "weight",
      "graph.test-lcc-directed.meta.vertices": "10",
      "graph.example-directed.edge-properties.names": "weight",
      "graph.wiki-Talk.meta.vertices": "2394385",
      "graph.datagen-sf10k-fb.sssp.weight-property": "weight",
      "graph.datagen-9_1-fb.vertex-file": "datagen-9_1-fb.v",
      "graph.datagen-sf10k-fb.bfs.source-vertex": "933",
      "graph.test-sssp-directed.algorithms": "sssp",
      "graph.datagen-8_4-fb.meta.edges": "269479177",
      "graph.graph500-29.meta.edges": "8493569115",
      "graph.datagen-9_4-fb.pr.num-iterations": "10",
      "graph.graph500-25.bfs.source-vertex": "24460635",
      "graph.example-undirected.cdlp.max-iterations": "2",
      "graph.kgs.bfs.source-vertex": "239044",
      "graph.datagen-7_7-zf.edge-properties.types": "real",
      "graph.datagen-9_2-zf.pr.num-iterations": "10",
      "graph.graph500-27.directed": "false",
      "graph.datagen-sf3k-fb.cdlp.max-iterations": "10",
      "graph.kgs.vertex-file": "kgs.v",
      "graph.datagen-8_7-zf.sssp.weight-property": "weight",
      "graph.test-pr-undirected.algorithms": "pr",
      "graph.graph500-25.pr.num-iterations": "10",
      "graph.datagen-sf3k-fb.sssp.source-vertex": "6",
      "graph.test-pr-directed.directed": "true",
      "graph.cit-Patents.cdlp.max-iterations": "10",
      "graph.datagen-9_4-fb.algorithms": "bfs",
      "platform.version": "1.0",
      "graph.test-pr-undirected.pr.damping-factor": "0.85",
      "graph.datagen-8_8-zf.vertex-file": "datagen-8_8-zf.v",
      "graph.graph500-30.meta.edges": "17022117362",
      "graph.wiki-Talk.pr.damping-factor": "0.85",
      "graph.example-undirected.vertex-file": "example-undirected.v",
      "graph.datagen-8_4-fb.sssp.source-vertex": "6",
      "graph.datagen-8_8-zf.edge-properties.names": "weight",
      "graph.datagen-sf10k-fb.meta.vertices": "100218750",
      "graph.example-undirected.edge-properties.types": "real",
      "graph.graph500-26.pr.num-iterations": "10",
      "graph.test-lcc-undirected.vertex-file": "test-lcc-undirected.v",
      "graph.dota-league.vertex-file": "dota-league.v",
      "graph.datagen-7_7-zf.edge-file": "datagen-7_7-zf.e",
      "graph.datagen-9_3-zf.meta.vertices": "555270053",
      "graph.datagen-9_3-zf.algorithms": "bfs",
      "graph.twitter_mpi.directed": "true",
      "system.pricing": "",
      "graph.test-sssp-undirected.meta.edges": "14",
      "benchmark.custom.repetitions": "1",
      "graph.example-undirected.algorithms": "bfs",
      "graph.test-pr-undirected.directed": "false",
      "graph.datagen-8_2-zf.meta.edges": "106440188",
      "graph.datagen-8_5-fb.pr.damping-factor": "0.85",
      "graph.dota-league.algorithms": "bfs",
      "graph.datagen-8_6-fb.edge-file": "datagen-8_6-fb.e",
      "graph.datagen-8_6-fb.edge-properties.types": "real",
      "graphs.root-directory": "/home/devcloud/graphalytics_data/S/",
      "graph.datagen-7_7-zf.pr.num-iterations": "10",
      "graph.com-friendster.vertex-file": "com-friendster.v",
      "graph.graph500-25.meta.edges": "523602831",
      "graph.datagen-7_5-fb.meta.vertices": "633432",
      "graph.test-pr-directed.meta.edges": "246",
      "graph.twitter_mpi.meta.vertices": "52579678",
      "graph.datagen-8_6-fb.pr.num-iterations": "10",
      "graph.test-sssp-directed.edge-properties.types": "real",
      "graph.test-pr-undirected.edge-file": "test-pr-undirected.e",
      "graph.test-wcc-directed.edge-file": "test-wcc-directed.e",
      "graph.kgs.meta.edges": "17891698",
      "graph.datagen-7_5-fb.cdlp.max-iterations": "10",
      "graph.test-wcc-directed.algorithms": "wcc",
      "graph.datagen-9_2-zf.algorithms": "bfs",
      "graph.datagen-7_6-fb.edge-properties.types": "real",
      "graph.datagen-9_0-fb.pr.num-iterations": "10",
      "graph.datagen-8_3-zf.meta.edges": "130579909",
      "graph.datagen-8_7-zf.pr.damping-factor": "0.85",
      "graph.datagen-8_8-zf.pr.num-iterations": "10",
      "graph.example-directed.pr.damping-factor": "0.85",
      "graph.datagen-8_0-fb.directed": "false",
      "graph.datagen-8_9-fb.meta.edges": "848681908",
      "graph.datagen-9_0-fb.directed": "false",
      "graph.datagen-7_9-fb.bfs.source-vertex": "6",
      "graph.datagen-7_8-zf.cdlp.max-iterations": "10",
      "environment.version": "",
      "graph.datagen-9_4-fb.bfs.source-vertex": "6",
      "graph.datagen-9_3-zf.sssp.source-vertex": "6",
      "graph.example-directed.meta.vertices": "10",
      "graph.datagen-8_4-fb.directed": "false",
      "graph.datagen-sf10k-fb.meta.edges": "9404822538"
    }
  },
  "result": {
    "experiments": {
      "e533525": {
        "id": "e533525",
        "type": "custom:exp",
        "jobs": [
          "j739961",
          "j920512",
          "j824208",
          "j812101",
          "j783665",
          "j764651",
          "j604911",
          "j488179",
          "j803195",
          "j842404",
          "j701040",
          "j492592",
          "j870026",
          "j812678",
          "j590465",
          "j708887",
          "j830625",
          "j835720",
          "j794704",
          "j898427",
          "j919142",
          "j700233",
          "j577918",
          "j908915",
          "j656353",
          "j641076",
          "j694498",
          "j653202",
          "j760399",
          "j824383",
          "j744006",
          "j892304",
          "j733429",
          "j703802",
          "j864689",
          "j552193",
          "j643423",
          "j506073",
          "j628707",
          "j529435",
          "j581553",
          "j568942",
          "j784843",
          "j742005",
          "j882660",
          "j744741",
          "j533898",
          "j783269",
          "j902825",
          "j515637",
          "j852545",
          "j496203",
          "j752143",
          "j827958",
          "j855835",
          "j473854",
          "j917052"
        ]
      }
    },
    "jobs": {
      "j703802": {
        "id": "j703802",
        "algorithm": "CDLP",
        "dataset": "graph500-22",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r833895"
        ]
      },
      "j920512": {
        "id": "j920512",
        "algorithm": "BFS",
        "dataset": "datagen-7_6-fb",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r736900"
        ]
      },
      "j641076": {
        "id": "j641076",
        "algorithm": "WCC",
        "dataset": "wiki-Talk",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r908417"
        ]
      },
      "j898427": {
        "id": "j898427",
        "algorithm": "WCC",
        "dataset": "datagen-7_7-zf",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r472822"
        ]
      },
      "j852545": {
        "id": "j852545",
        "algorithm": "LCC",
        "dataset": "datagen-7_8-zf",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r665150"
        ]
      },
      "j835720": {
        "id": "j835720",
        "algorithm": "WCC",
        "dataset": "datagen-7_5-fb",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r907651"
        ]
      },
      "j760399": {
        "id": "j760399",
        "algorithm": "CDLP",
        "dataset": "datagen-7_6-fb",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r726413"
        ]
      },
      "j568942": {
        "id": "j568942",
        "algorithm": "PR",
        "dataset": "dota-league",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r639622"
        ]
      },
      "j784843": {
        "id": "j784843",
        "algorithm": "PR",
        "dataset": "kgs",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r708451"
        ]
      },
      "j506073": {
        "id": "j506073",
        "algorithm": "PR",
        "dataset": "datagen-7_5-fb",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r802871"
        ]
      },
      "j864689": {
        "id": "j864689",
        "algorithm": "CDLP",
        "dataset": "datagen-7_9-fb",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r525427"
        ]
      },
      "j473854": {
        "id": "j473854",
        "algorithm": "LCC",
        "dataset": "wiki-Talk",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r621391"
        ]
      },
      "j824383": {
        "id": "j824383",
        "algorithm": "CDLP",
        "dataset": "datagen-7_7-zf",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r735317"
        ]
      },
      "j744741": {
        "id": "j744741",
        "algorithm": "PR",
        "dataset": "wiki-Talk",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r488000"
        ]
      },
      "j812678": {
        "id": "j812678",
        "algorithm": "SSSP",
        "dataset": "datagen-7_8-zf",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r540035"
        ]
      },
      "j764651": {
        "id": "j764651",
        "algorithm": "BFS",
        "dataset": "kgs",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r563720"
        ]
      },
      "j742005": {
        "id": "j742005",
        "algorithm": "PR",
        "dataset": "graph500-22",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r888565"
        ]
      },
      "j870026": {
        "id": "j870026",
        "algorithm": "SSSP",
        "dataset": "datagen-7_7-zf",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r624966"
        ]
      },
      "j590465": {
        "id": "j590465",
        "algorithm": "SSSP",
        "dataset": "dota-league",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r667650"
        ]
      },
      "j708887": {
        "id": "j708887",
        "algorithm": "SSSP",
        "dataset": "kgs",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r484729"
        ]
      },
      "j908915": {
        "id": "j908915",
        "algorithm": "WCC",
        "dataset": "graph500-22",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r913374"
        ]
      },
      "j488179": {
        "id": "j488179",
        "algorithm": "BFS",
        "dataset": "datagen-7_9-fb",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r571421"
        ]
      },
      "j653202": {
        "id": "j653202",
        "algorithm": "CDLP",
        "dataset": "datagen-7_5-fb",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r599698"
        ]
      },
      "j739961": {
        "id": "j739961",
        "algorithm": "BFS",
        "dataset": "datagen-7_5-fb",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r572741"
        ]
      },
      "j628707": {
        "id": "j628707",
        "algorithm": "PR",
        "dataset": "datagen-7_6-fb",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r662785"
        ]
      },
      "j656353": {
        "id": "j656353",
        "algorithm": "WCC",
        "dataset": "datagen-7_9-fb",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r921815"
        ]
      },
      "j733429": {
        "id": "j733429",
        "algorithm": "CDLP",
        "dataset": "kgs",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r764894"
        ]
      },
      "j604911": {
        "id": "j604911",
        "algorithm": "BFS",
        "dataset": "graph500-22",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r865064"
        ]
      },
      "j581553": {
        "id": "j581553",
        "algorithm": "PR",
        "dataset": "datagen-7_8-zf",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r563572"
        ]
      },
      "j492592": {
        "id": "j492592",
        "algorithm": "SSSP",
        "dataset": "datagen-7_6-fb",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r490953"
        ]
      },
      "j855835": {
        "id": "j855835",
        "algorithm": "LCC",
        "dataset": "datagen-7_9-fb",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r480333"
        ]
      },
      "j812101": {
        "id": "j812101",
        "algorithm": "BFS",
        "dataset": "datagen-7_8-zf",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r778027"
        ]
      },
      "j700233": {
        "id": "j700233",
        "algorithm": "WCC",
        "dataset": "dota-league",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r758016"
        ]
      },
      "j824208": {
        "id": "j824208",
        "algorithm": "BFS",
        "dataset": "datagen-7_7-zf",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r504180"
        ]
      },
      "j827958": {
        "id": "j827958",
        "algorithm": "LCC",
        "dataset": "graph500-22",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r728107"
        ]
      },
      "j515637": {
        "id": "j515637",
        "algorithm": "LCC",
        "dataset": "datagen-7_7-zf",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r714023"
        ]
      },
      "j917052": {
        "id": "j917052",
        "algorithm": "LCC",
        "dataset": "cit-Patents",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r678839"
        ]
      },
      "j902825": {
        "id": "j902825",
        "algorithm": "LCC",
        "dataset": "datagen-7_6-fb",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r535286"
        ]
      },
      "j533898": {
        "id": "j533898",
        "algorithm": "PR",
        "dataset": "cit-Patents",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r868846"
        ]
      },
      "j496203": {
        "id": "j496203",
        "algorithm": "LCC",
        "dataset": "dota-league",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r716348"
        ]
      },
      "j552193": {
        "id": "j552193",
        "algorithm": "CDLP",
        "dataset": "wiki-Talk",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r865819"
        ]
      },
      "j643423": {
        "id": "j643423",
        "algorithm": "CDLP",
        "dataset": "cit-Patents",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r897496"
        ]
      },
      "j529435": {
        "id": "j529435",
        "algorithm": "PR",
        "dataset": "datagen-7_7-zf",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r628399"
        ]
      },
      "j830625": {
        "id": "j830625",
        "algorithm": "SSSP",
        "dataset": "datagen-7_9-fb",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r845270"
        ]
      },
      "j744006": {
        "id": "j744006",
        "algorithm": "CDLP",
        "dataset": "datagen-7_8-zf",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r548006"
        ]
      },
      "j892304": {
        "id": "j892304",
        "algorithm": "CDLP",
        "dataset": "dota-league",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r483569"
        ]
      },
      "j783665": {
        "id": "j783665",
        "algorithm": "BFS",
        "dataset": "dota-league",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r768133"
        ]
      },
      "j783269": {
        "id": "j783269",
        "algorithm": "LCC",
        "dataset": "datagen-7_5-fb",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r502818"
        ]
      },
      "j577918": {
        "id": "j577918",
        "algorithm": "WCC",
        "dataset": "kgs",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r789406"
        ]
      },
      "j842404": {
        "id": "j842404",
        "algorithm": "BFS",
        "dataset": "cit-Patents",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r644363"
        ]
      },
      "j701040": {
        "id": "j701040",
        "algorithm": "SSSP",
        "dataset": "datagen-7_5-fb",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r565452"
        ]
      },
      "j752143": {
        "id": "j752143",
        "algorithm": "LCC",
        "dataset": "kgs",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r662958"
        ]
      },
      "j882660": {
        "id": "j882660",
        "algorithm": "PR",
        "dataset": "datagen-7_9-fb",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r912125"
        ]
      },
      "j794704": {
        "id": "j794704",
        "algorithm": "WCC",
        "dataset": "datagen-7_6-fb",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r556165"
        ]
      },
      "j694498": {
        "id": "j694498",
        "algorithm": "WCC",
        "dataset": "cit-Patents",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r804227"
        ]
      },
      "j803195": {
        "id": "j803195",
        "algorithm": "BFS",
        "dataset": "wiki-Talk",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r842770"
        ]
      },
      "j919142": {
        "id": "j919142",
        "algorithm": "WCC",
        "dataset": "datagen-7_8-zf",
        "scale": "1",
        "repetition": "1",
        "runs": [
          "r724445"
        ]
      }
    },
    "runs": {
      "r764894": {
        "id": "r764894",
        "timestamp": "1683906551470",
        "success": "true",
        "load_time": "11.036",
        "makespan": "5.624",
        "processing_time": "4.314"
      },
      "r572741": {
        "id": "r572741",
        "timestamp": "1683905390133",
        "success": "true",
        "load_time": "19.884",
        "makespan": "1.320",
        "processing_time": "0.031"
      },
      "r565452": {
        "id": "r565452",
        "timestamp": "1683905456743",
        "success": "true",
        "load_time": "28.464",
        "makespan": "2.591",
        "processing_time": "0.550"
      },
      "r662785": {
        "id": "r662785",
        "timestamp": "1683905538937",
        "success": "true",
        "load_time": "23.964",
        "makespan": "2.069",
        "processing_time": "0.229"
      },
      "r758016": {
        "id": "r758016",
        "timestamp": "1683906412139",
        "success": "true",
        "load_time": "26.167",
        "makespan": "0.670",
        "processing_time": "0.016"
      },
      "r778027": {
        "id": "r778027",
        "timestamp": "1683906185722",
        "success": "true",
        "load_time": "30.278",
        "makespan": "17.027",
        "processing_time": "0.172"
      },
      "r644363": {
        "id": "r644363",
        "timestamp": "1683907161884",
        "success": "true",
        "load_time": "11.233",
        "makespan": "4.280",
        "processing_time": "0.059"
      },
      "r628399": {
        "id": "r628399",
        "timestamp": "1683905782484",
        "success": "true",
        "load_time": "24.528",
        "makespan": "18.456",
        "processing_time": "0.271"
      },
      "r726413": {
        "id": "r726413",
        "timestamp": "1683905512881",
        "success": "true",
        "load_time": "23.964",
        "makespan": "12.152",
        "processing_time": "10.609"
      },
      "r736900": {
        "id": "r736900",
        "timestamp": "1683905573059",
        "success": "true",
        "load_time": "23.964",
        "makespan": "1.520",
        "processing_time": "0.051"
      },
      "r540035": {
        "id": "r540035",
        "timestamp": "1683906261704",
        "success": "true",
        "load_time": "38.906",
        "makespan": "25.624",
        "processing_time": "2.662"
      },
      "r472822": {
        "id": "r472822",
        "timestamp": "1683905820545",
        "success": "true",
        "load_time": "24.528",
        "makespan": "13.809",
        "processing_time": "0.198"
      },
      "r768133": {
        "id": "r768133",
        "timestamp": "1683906379014",
        "success": "true",
        "load_time": "26.167",
        "makespan": "0.634",
        "processing_time": "0.017"
      },
      "r488000": {
        "id": "r488000",
        "timestamp": "1683907027288",
        "success": "true",
        "load_time": "4.264",
        "makespan": "4.290",
        "processing_time": "0.205"
      },
      "r490953": {
        "id": "r490953",
        "timestamp": "1683905622690",
        "success": "true",
        "load_time": "34.553",
        "makespan": "3.011",
        "processing_time": "0.615"
      },
      "r714023": {
        "id": "r714023",
        "timestamp": "1683905710355",
        "success": "true",
        "load_time": "24.528",
        "makespan": "18.508",
        "processing_time": "0.728"
      },
      "r908417": {
        "id": "r908417",
        "timestamp": "1683907102537",
        "success": "true",
        "load_time": "4.264",
        "makespan": "3.196",
        "processing_time": "0.203"
      },
      "r571421": {
        "id": "r571421",
        "timestamp": "1683906827816",
        "success": "true",
        "load_time": "46.743",
        "makespan": "2.673",
        "processing_time": "0.058"
      },
      "r789406": {
        "id": "r789406",
        "timestamp": "1683906570518",
        "success": "true",
        "load_time": "11.036",
        "makespan": "1.437",
        "processing_time": "0.126"
      },
      "r599698": {
        "id": "r599698",
        "timestamp": "1683905405197",
        "success": "true",
        "load_time": "19.884",
        "makespan": "9.699",
        "processing_time": "8.407"
      },
      "r888565": {
        "id": "r888565",
        "timestamp": "1683906985894",
        "success": "true",
        "load_time": "35.755",
        "makespan": "4.536",
        "processing_time": "0.218"
      },
      "r865064": {
        "id": "r865064",
        "timestamp": "1683907004956",
        "success": "true",
        "load_time": "35.755",
        "makespan": "3.471",
        "processing_time": "0.062"
      },
      "r845270": {
        "id": "r845270",
        "timestamp": "1683906686812",
        "success": "true",
        "load_time": "68.235",
        "makespan": "4.620",
        "processing_time": "0.925"
      },
      "r921815": {
        "id": "r921815",
        "timestamp": "1683906773685",
        "success": "true",
        "load_time": "46.743",
        "makespan": "2.912",
        "processing_time": "0.112"
      },
      "r535286": {
        "id": "r535286",
        "timestamp": "1683905554994",
        "success": "true",
        "load_time": "23.964",
        "makespan": "4.229",
        "processing_time": "2.394"
      },
      "r624966": {
        "id": "r624966",
        "timestamp": "1683905907112",
        "success": "true",
        "load_time": "32.492",
        "makespan": "20.469",
        "processing_time": "2.117"
      },
      "r728107": {
        "id": "r728107",
        "timestamp": "1683906919758",
        "success": "true",
        "load_time": "35.755",
        "makespan": "19.038",
        "processing_time": "15.102"
      },
      "r556165": {
        "id": "r556165",
        "timestamp": "1683905496782",
        "success": "true",
        "load_time": "23.964",
        "makespan": "1.566",
        "processing_time": "0.093"
      },
      "r563720": {
        "id": "r563720",
        "timestamp": "1683906521347",
        "success": "true",
        "load_time": "11.036",
        "makespan": "1.347",
        "processing_time": "0.040"
      },
      "r842770": {
        "id": "r842770",
        "timestamp": "1683907046357",
        "success": "true",
        "load_time": "4.264",
        "makespan": "3.036",
        "processing_time": "0.065"
      },
      "r502818": {
        "id": "r502818",
        "timestamp": "1683905357993",
        "success": "true",
        "load_time": "19.884",
        "makespan": "3.483",
        "processing_time": "1.872"
      },
      "r907651": {
        "id": "r907651",
        "timestamp": "1683905341931",
        "success": "true",
        "load_time": "19.884",
        "makespan": "1.322",
        "processing_time": "0.085"
      },
      "r667650": {
        "id": "r667650",
        "timestamp": "1683906477171",
        "success": "true",
        "load_time": "36.902",
        "makespan": "1.855",
        "processing_time": "0.572"
      },
      "r913374": {
        "id": "r913374",
        "timestamp": "1683906897705",
        "success": "true",
        "load_time": "35.755",
        "makespan": "3.829",
        "processing_time": "0.173"
      },
      "r833895": {
        "id": "r833895",
        "timestamp": "1683906952819",
        "success": "true",
        "load_time": "35.755",
        "makespan": "18.983",
        "processing_time": "15.456"
      },
      "r665150": {
        "id": "r665150",
        "timestamp": "1683906141662",
        "success": "true",
        "load_time": "30.278",
        "makespan": "23.120",
        "processing_time": "0.891"
      },
      "r678839": {
        "id": "r678839",
        "timestamp": "1683907180958",
        "success": "true",
        "load_time": "11.233",
        "makespan": "5.876",
        "processing_time": "0.589"
      },
      "r563572": {
        "id": "r563572",
        "timestamp": "1683906044524",
        "success": "true",
        "load_time": "30.278",
        "makespan": "22.854",
        "processing_time": "0.355"
      },
      "r912125": {
        "id": "r912125",
        "timestamp": "1683906843877",
        "success": "true",
        "load_time": "46.743",
        "makespan": "3.764",
        "processing_time": "0.263"
      },
      "r639622": {
        "id": "r639622",
        "timestamp": "1683906426203",
        "success": "true",
        "load_time": "26.167",
        "makespan": "0.826",
        "processing_time": "0.101"
      },
      "r735317": {
        "id": "r735317",
        "timestamp": "1683905664286",
        "success": "true",
        "load_time": "24.528",
        "makespan": "26.560",
        "processing_time": "12.134"
      },
      "r802871": {
        "id": "r802871",
        "timestamp": "1683905375065",
        "success": "true",
        "load_time": "19.884",
        "makespan": "1.810",
        "processing_time": "0.209"
      },
      "r868846": {
        "id": "r868846",
        "timestamp": "1683907226092",
        "success": "true",
        "load_time": "11.233",
        "makespan": "6.367",
        "processing_time": "0.272"
      },
      "r865819": {
        "id": "r865819",
        "timestamp": "1683907063412",
        "success": "true",
        "load_time": "4.264",
        "makespan": "6.565",
        "processing_time": "3.550"
      },
      "r662958": {
        "id": "r662958",
        "timestamp": "1683906503288",
        "success": "true",
        "load_time": "11.036",
        "makespan": "3.923",
        "processing_time": "2.221"
      },
      "r548006": {
        "id": "r548006",
        "timestamp": "1683906089594",
        "success": "true",
        "load_time": "30.278",
        "makespan": "31.828",
        "processing_time": "14.680"
      },
      "r716348": {
        "id": "r716348",
        "timestamp": "1683906335952",
        "success": "true",
        "load_time": "26.167",
        "makespan": "30.568",
        "processing_time": "29.906"
      },
      "r525427": {
        "id": "r525427",
        "timestamp": "1683906792752",
        "success": "true",
        "load_time": "46.743",
        "makespan": "21.311",
        "processing_time": "18.487"
      },
      "r621391": {
        "id": "r621391",
        "timestamp": "1683907084476",
        "success": "true",
        "load_time": "4.264",
        "makespan": "4.167",
        "processing_time": "0.435"
      },
      "r484729": {
        "id": "r484729",
        "timestamp": "1683906602504",
        "success": "true",
        "load_time": "14.920",
        "makespan": "2.436",
        "processing_time": "0.611"
      },
      "r483569": {
        "id": "r483569",
        "timestamp": "1683906393076",
        "success": "true",
        "load_time": "26.167",
        "makespan": "5.803",
        "processing_time": "5.015"
      },
      "r504180": {
        "id": "r504180",
        "timestamp": "1683905748418",
        "success": "true",
        "load_time": "24.528",
        "makespan": "14.172",
        "processing_time": "0.209"
      },
      "r724445": {
        "id": "r724445",
        "timestamp": "1683905978457",
        "success": "true",
        "load_time": "30.278",
        "makespan": "16.911",
        "processing_time": "0.260"
      },
      "r480333": {
        "id": "r480333",
        "timestamp": "1683906752634",
        "success": "true",
        "load_time": "46.743",
        "makespan": "7.490",
        "processing_time": "4.520"
      },
      "r708451": {
        "id": "r708451",
        "timestamp": "1683906536412",
        "success": "true",
        "load_time": "11.036",
        "makespan": "1.887",
        "processing_time": "0.189"
      },
      "r897496": {
        "id": "r897496",
        "timestamp": "1683907135839",
        "success": "true",
        "load_time": "11.233",
        "makespan": "11.987",
        "processing_time": "7.210"
      },
      "r804227": {
        "id": "r804227",
        "timestamp": "1683907202023",
        "success": "true",
        "load_time": "11.233",
        "makespan": "4.678",
        "processing_time": "0.314"
      }
    }
  }
}